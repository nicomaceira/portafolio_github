#Programa que al introducir un número por teclado permita mostrar ese número de veces tu nombre
numero = int(input("Introduce un número: "))
for i in range(numero):
    print("Nicolás Maceira")  
