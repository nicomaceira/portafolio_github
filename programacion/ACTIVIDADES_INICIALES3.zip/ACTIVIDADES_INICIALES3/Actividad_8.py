#Imprima el siguiente patrón con el ciclo for
for i in range(1, 6):
    print('*' * i)
for i in range(4, 0, -1):
    print('*' * i)
